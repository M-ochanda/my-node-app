const express = require('express');
const app = express();

const PORT = process.env.PORT || 3000;

app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>My Azure Web App</title>
      <style>
        body {
          margin: 0;
          font-family: Arial, sans-serif;
          background: linear-gradient(135deg, #0078D4, #6B46C1);
          color: white;
          display: flex;
          justify-content: center;
          align-items: center;
          height: 100vh;
        }

        .card {
          background: rgba(255, 255, 255, 0.12);
          padding: 40px;
          border-radius: 20px;
          text-align: center;
          box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
          max-width: 600px;
          width: 90%;
        }

        h1 {
          margin-bottom: 15px;
          font-size: 2rem;
        }

        p {
          font-size: 1.1rem;
          line-height: 1.6;
        }

        .btn {
          display: inline-block;
          margin-top: 20px;
          padding: 12px 24px;
          background: white;
          color: #0078D4;
          text-decoration: none;
          border-radius: 10px;
          font-weight: bold;
        }

        .btn:hover {
          background: #f3f3f3;
        }
      </style>
    </head>
    <body>
      <div class="card">
        <h1>Hello Mitchelle! </h1>
        <p>Your Azure Web App is now running successfully.</p>
        <p>This page is coming from your Node.js app deployed on Azure App Service.</p>
        <a href="#" class="btn">It works !</a>
      </div>
    </body>
    </html>
  `);
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
